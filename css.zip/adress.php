<?php

    $adress = "https://poemse.com/nazr/"
?>